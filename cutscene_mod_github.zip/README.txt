Cutscene Player - Forge 1.20.1

البناء بدون تثبيت اي شي: ارفع هالمجلد كامل على GitHub، وتاب Actions بيبني المود.

الاستعمال بالعبة (المود عند السيرفر وكل اللاعبين):
  مجلد  cutscenes  داخل مجلد السيرفر وحط فيه الفيديو (mp4).
  /cutscene play <لاعب> <اسم الملف>
  /cutscene stop <لاعب>
  /cutscene list
