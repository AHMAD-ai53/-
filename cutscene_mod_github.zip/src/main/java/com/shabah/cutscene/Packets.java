package com.shabah.cutscene;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class Packets {

    /** server -> client : start this video (client downloads it first if needed) */
    public static class Play {
        public final String name; public final long size, stamp;
        public Play(String name, long size, long stamp) { this.name = name; this.size = size; this.stamp = stamp; }
        public static void encode(Play p, FriendlyByteBuf b) { b.writeUtf(p.name); b.writeLong(p.size); b.writeLong(p.stamp); }
        public static Play decode(FriendlyByteBuf b) { return new Play(b.readUtf(), b.readLong(), b.readLong()); }
        public static void handle(Play p, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHandler.onPlay(p)));
            c.get().setPacketHandled(true);
        }
    }

    /** server -> client : a piece of the video file */
    public static class Chunk {
        public final String name; public final int index, total; public final byte[] data;
        public Chunk(String name, int index, int total, byte[] data) { this.name = name; this.index = index; this.total = total; this.data = data; }
        public static void encode(Chunk p, FriendlyByteBuf b) { b.writeUtf(p.name); b.writeInt(p.index); b.writeInt(p.total); b.writeByteArray(p.data); }
        public static Chunk decode(FriendlyByteBuf b) { return new Chunk(b.readUtf(), b.readInt(), b.readInt(), b.readByteArray()); }
        public static void handle(Chunk p, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHandler.onChunk(p)));
            c.get().setPacketHandled(true);
        }
    }

    /** server -> client : stop the cutscene now */
    public static class Stop {
        public static void encode(Stop p, FriendlyByteBuf b) { }
        public static Stop decode(FriendlyByteBuf b) { return new Stop(); }
        public static void handle(Stop p, Supplier<NetworkEvent.Context> c) {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHandler::onStop));
            c.get().setPacketHandled(true);
        }
    }

    /** client -> server : I don't have this file, send it */
    public static class Need {
        public final String name;
        public Need(String name) { this.name = name; }
        public static void encode(Need p, FriendlyByteBuf b) { b.writeUtf(p.name); }
        public static Need decode(FriendlyByteBuf b) { return new Need(b.readUtf()); }
        public static void handle(Need p, Supplier<NetworkEvent.Context> c) {
            ServerPlayer sp = c.get().getSender();
            c.get().enqueueWork(() -> { if (sp != null) CutsceneCommand.sendFile(sp, p.name); });
            c.get().setPacketHandled(true);
        }
    }
}
