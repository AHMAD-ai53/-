package com.shabah.cutscene;

import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileTime;

/** Client-only. Only touched through DistExecutor. */
public class ClientHandler {
    private static final Path CACHE = FMLPaths.GAMEDIR.get().resolve("cutscene_cache");
    private static String pending;
    private static long pendingStamp;
    private static Path part;
    private static OutputStream out;

    private static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), true);
    }

    public static void onPlay(Packets.Play p) {
        try {
            Files.createDirectories(CACHE);
            Path f = CACHE.resolve(p.name);
            if (Files.isRegularFile(f) && Files.size(f) == p.size
                    && Math.abs(Files.getLastModifiedTime(f).toMillis() - p.stamp) < 2000) {
                start(f);
                return;
            }
            closeOut();
            pending = p.name;
            pendingStamp = p.stamp;
            part = CACHE.resolve(p.name + ".part");
            out = Files.newOutputStream(part);
            msg("Downloading cutscene...");
            Net.CH.sendToServer(new Packets.Need(p.name));
        } catch (IOException e) {
            msg("Cutscene error: " + e.getMessage());
        }
    }

    public static void onChunk(Packets.Chunk c) {
        if (out == null || pending == null || !pending.equals(c.name)) return;
        try {
            out.write(c.data);
            if (c.index >= c.total - 1) {
                closeOut();
                Path f = CACHE.resolve(pending);
                Files.move(part, f, StandardCopyOption.REPLACE_EXISTING);
                Files.setLastModifiedTime(f, FileTime.fromMillis(pendingStamp));
                pending = null;
                start(f);
            }
        } catch (IOException e) {
            msg("Cutscene error: " + e.getMessage());
            closeOut();
        }
    }

    public static void onStop() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof CutsceneScreen s) s.stop();
    }

    private static void closeOut() {
        try { if (out != null) out.close(); } catch (IOException ignored) { }
        out = null;
    }

    private static void start(Path f) {
        VideoPlayer vp = new VideoPlayer(f);
        try {
            vp.open();
        } catch (Throwable t) {
            msg("Can't open video: " + t.getMessage());
            return;
        }
        Minecraft.getInstance().setScreen(new CutsceneScreen(vp));
    }
}
