package com.shabah.cutscene;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.io.IOException;
import java.nio.file.Files;

@Mod(CutsceneMod.MODID)
public class CutsceneMod {
    public static final String MODID = "cutscene";

    public CutsceneMod() {
        Net.register();
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        CutsceneCommand.register(e.getDispatcher());
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent e) {
        try { Files.createDirectories(CutsceneCommand.dir()); } catch (IOException ignored) { }
    }
}
