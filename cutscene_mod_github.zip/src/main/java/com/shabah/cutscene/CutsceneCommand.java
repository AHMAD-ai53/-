package com.shabah.cutscene;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.network.PacketDistributor;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CutsceneCommand {
    private static final int CHUNK = 30000;

    public static Path dir() { return FMLPaths.GAMEDIR.get().resolve("cutscenes"); }

    private static List<String> files() {
        try (Stream<Path> s = Files.list(dir())) {
            return s.filter(Files::isRegularFile).map(p -> p.getFileName().toString()).sorted().collect(Collectors.toList());
        } catch (IOException e) { return List.of(); }
    }

    /** returns null if the name is unsafe or the file doesn't exist */
    private static Path resolve(String name) {
        if (name == null || !name.matches("[\\w\\-. ()]+") || name.contains("..")) return null;
        Path base = dir().toAbsolutePath().normalize();
        Path p = base.resolve(name).normalize();
        if (!p.startsWith(base) || !Files.isRegularFile(p)) return null;
        return p;
    }

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("cutscene").requires(s -> s.hasPermission(2))
                .then(Commands.literal("play")
                        .then(Commands.argument("targets", EntityArgument.players())
                                .then(Commands.argument("file", StringArgumentType.greedyString())
                                        .suggests((c, b) -> SharedSuggestionProvider.suggest(files(), b))
                                        .executes(CutsceneCommand::play))))
                .then(Commands.literal("stop")
                        .then(Commands.argument("targets", EntityArgument.players())
                                .executes(CutsceneCommand::stop)))
                .then(Commands.literal("list").executes(CutsceneCommand::list)));
    }

    private static int play(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        String name = StringArgumentType.getString(ctx, "file");
        Path p = resolve(name);
        if (p == null) {
            ctx.getSource().sendFailure(Component.literal("File not found in /cutscenes: " + name));
            return 0;
        }
        long size, stamp;
        try { size = Files.size(p); stamp = Files.getLastModifiedTime(p).toMillis(); }
        catch (IOException e) { ctx.getSource().sendFailure(Component.literal("Can't read file")); return 0; }
        int n = 0;
        for (ServerPlayer pl : EntityArgument.getPlayers(ctx, "targets")) {
            Net.CH.send(PacketDistributor.PLAYER.with(() -> pl), new Packets.Play(name, size, stamp));
            n++;
        }
        final int count = n;
        ctx.getSource().sendSuccess(() -> Component.literal("Cutscene '" + name + "' sent to " + count + " player(s)"), true);
        return n;
    }

    private static int stop(CommandContext<CommandSourceStack> ctx) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        int n = 0;
        for (ServerPlayer pl : EntityArgument.getPlayers(ctx, "targets")) {
            Net.CH.send(PacketDistributor.PLAYER.with(() -> pl), new Packets.Stop());
            n++;
        }
        return n;
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        List<String> f = files();
        ctx.getSource().sendSuccess(() -> Component.literal(f.isEmpty() ? "No files in /cutscenes" : "Files: " + String.join(", ", f)), false);
        return f.size();
    }

    /** called when a client says it doesn't have the file */
    public static void sendFile(ServerPlayer pl, String name) {
        Path p = resolve(name);
        if (p == null) return;
        CompletableFuture.runAsync(() -> {
            try (InputStream in = Files.newInputStream(p)) {
                long size = Files.size(p);
                int total = (int) ((size + CHUNK - 1) / CHUNK);
                byte[] buf = new byte[CHUNK];
                int idx = 0, n;
                while ((n = in.readNBytes(buf, 0, CHUNK)) > 0) {
                    final int i = idx++;
                    final byte[] data = Arrays.copyOf(buf, n);
                    Net.CH.send(PacketDistributor.PLAYER.with(() -> pl), new Packets.Chunk(name, i, total, data));
                    if (i % 16 == 15) Thread.sleep(2);
                }
            } catch (Exception ignored) { }
        });
    }
}
