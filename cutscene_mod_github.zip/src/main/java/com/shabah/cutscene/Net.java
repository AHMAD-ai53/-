package com.shabah.cutscene;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CutsceneMod.MODID, "main"),
            () -> "1", "1"::equals, "1"::equals);

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, Packets.Play.class, Packets.Play::encode, Packets.Play::decode, Packets.Play::handle);
        CH.registerMessage(id++, Packets.Chunk.class, Packets.Chunk::encode, Packets.Chunk::decode, Packets.Chunk::handle);
        CH.registerMessage(id++, Packets.Stop.class, Packets.Stop::encode, Packets.Stop::decode, Packets.Stop::handle);
        CH.registerMessage(id++, Packets.Need.class, Packets.Need::encode, Packets.Need::decode, Packets.Need::handle);
    }
}
