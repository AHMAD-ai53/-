package com.shabah.cutscene;

import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundSource;
import org.bytedeco.ffmpeg.global.avutil;
import org.bytedeco.javacv.FFmpegFrameGrabber;

import javax.sound.sampled.*;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;
import java.nio.file.Path;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Consumer;

/** Decodes a video file on its own thread (video frames -> queue, audio -> speakers). */
public class VideoPlayer {
    public static class Frame {
        public ByteBuffer data; public int stride; public long ts;
    }

    private static final int POOL = 20;
    private static final int MAX_WIDTH = 1280;

    private final Path file;
    private FFmpegFrameGrabber g;
    public int width, height;

    private final ArrayBlockingQueue<Frame> free = new ArrayBlockingQueue<>(POOL);
    private final LinkedBlockingQueue<Frame> ready = new LinkedBlockingQueue<>();
    private volatile boolean stop, finished;
    private volatile long baseMicros, finishedNano;
    private volatile Throwable error;
    private SourceDataLine line;
    private Thread thread;
    private long startNano;

    public VideoPlayer(Path file) { this.file = file; }

    public void open() throws Exception {
        FFmpegFrameGrabber probe = new FFmpegFrameGrabber(file.toFile());
        probe.start();
        int w = probe.getImageWidth(), h = probe.getImageHeight();
        probe.stop();
        probe.release();
        if (w <= 0 || h <= 0) throw new IllegalStateException("no video stream");

        g = new FFmpegFrameGrabber(file.toFile());
        if (w > MAX_WIDTH) {
            h = (int) ((long) h * MAX_WIDTH / w) & ~1;
            w = MAX_WIDTH;
            g.setImageWidth(w);
            g.setImageHeight(h);
        }
        g.setPixelFormat(avutil.AV_PIX_FMT_RGBA);
        g.setSampleFormat(avutil.AV_SAMPLE_FMT_S16);
        g.setAudioChannels(2);
        g.start();
        width = g.getImageWidth();
        height = g.getImageHeight();
        for (int i = 0; i < POOL; i++) free.add(new Frame());
    }

    public void start() {
        startNano = System.nanoTime();
        thread = new Thread(this::run, "cutscene-decoder");
        thread.setDaemon(true);
        thread.start();
    }

    private void run() {
        try {
            if (g.hasAudio() && g.getSampleRate() > 0) {
                AudioFormat af = new AudioFormat(g.getSampleRate(), 16, g.getAudioChannels(), true, false);
                line = (SourceDataLine) AudioSystem.getLine(new DataLine.Info(SourceDataLine.class, af));
                line.open(af);
                line.start();
            }
            startNano = System.nanoTime();
            org.bytedeco.javacv.Frame f;
            while (!stop && (f = g.grab()) != null) {
                if (f.image != null && f.image[0] != null) {
                    ByteBuffer src = (ByteBuffer) f.image[0];
                    Frame out = free.take();
                    int need = src.remaining();
                    if (out.data == null || out.data.capacity() < need) out.data = ByteBuffer.allocateDirect(need);
                    out.data.clear();
                    out.data.put(src.duplicate());
                    out.data.flip();
                    out.stride = f.imageStride;
                    out.ts = f.timestamp;
                    ready.add(out);
                } else if (f.samples != null && line != null) {
                    ShortBuffer sb = (ShortBuffer) f.samples[0];
                    sb.rewind();
                    float vol = Minecraft.getInstance().options.getSoundSourceVolume(SoundSource.MASTER);
                    byte[] b = new byte[sb.remaining() * 2];
                    int i = 0;
                    while (sb.hasRemaining()) {
                        short s = (short) (sb.get() * vol);
                        b[i++] = (byte) (s & 0xFF);
                        b[i++] = (byte) ((s >> 8) & 0xFF);
                    }
                    line.write(b, 0, b.length);
                }
            }
            if (line != null && !stop) line.drain();
        } catch (InterruptedException ignored) {
        } catch (Throwable t) {
            error = t;
        } finally {
            baseMicros = clockMicros();
            finishedNano = System.nanoTime();
            finished = true;
        }
    }

    private long clockMicros() {
        if (finishedNano != 0) return baseMicros + (System.nanoTime() - finishedNano) / 1000;
        if (line != null) return line.getMicrosecondPosition();
        return (System.nanoTime() - startNano) / 1000;
    }

    /** Render thread: gives the newest frame whose time has come (if any) to the consumer. */
    public void pollFrame(Consumer<Frame> consumer) {
        long clock = clockMicros();
        Frame latest = null;
        Frame n;
        while ((n = ready.peek()) != null && n.ts <= clock) {
            ready.poll();
            if (latest != null) free.offer(latest);
            latest = n;
        }
        if (latest != null) {
            consumer.accept(latest);
            free.offer(latest);
        }
    }

    public boolean isDone() { return finished && ready.isEmpty(); }
    public Throwable getError() { return error; }

    public void close() {
        stop = true;
        if (thread != null) {
            thread.interrupt();
            try { thread.join(2000); } catch (InterruptedException ignored) { }
        }
        try { if (line != null) { line.stop(); line.flush(); line.close(); } } catch (Throwable ignored) { }
        try { if (g != null) { g.stop(); g.release(); } } catch (Throwable ignored) { }
    }
}
