package com.shabah.cutscene;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;

/** Fullscreen, no HUD, can't be closed by the player. Closes itself when the video ends. */
public class CutsceneScreen extends Screen {
    private final VideoPlayer player;
    private DynamicTexture tex;
    private ResourceLocation texLoc;
    private boolean started, closing;

    public CutsceneScreen(VideoPlayer player) {
        super(Component.empty());
        this.player = player;
    }

    @Override
    protected void init() {
        if (started) return;
        started = true;
        tex = new DynamicTexture(player.width, player.height, false);
        texLoc = new ResourceLocation(CutsceneMod.MODID, "video_frame");
        minecraft.getTextureManager().register(texLoc, tex);
        minecraft.getSoundManager().pause();
        GLFW.glfwSetInputMode(minecraft.getWindow().getWindow(), GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_HIDDEN);
        player.start();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xFF000000);
        g.flush();

        player.pollFrame(f -> {
            RenderSystem.bindTexture(tex.getId());
            GlStateManager._pixelStore(GL11.GL_UNPACK_ROW_LENGTH, f.stride / 4);
            GL11.glTexSubImage2D(GL11.GL_TEXTURE_2D, 0, 0, 0, player.width, player.height,
                    GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, f.data);
            GlStateManager._pixelStore(GL11.GL_UNPACK_ROW_LENGTH, 0);
        });

        double sc = Math.min((double) width / player.width, (double) height / player.height);
        float w = (float) (player.width * sc), h = (float) (player.height * sc);
        float x = (width - w) / 2f, y = (height - h) / 2f;

        RenderSystem.setShader(GameRenderer::getPositionTexShader);
        RenderSystem.setShaderTexture(0, texLoc);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        Matrix4f m = g.pose().last().pose();
        BufferBuilder bb = Tesselator.getInstance().getBuilder();
        bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        bb.vertex(m, x, y + h, 0).uv(0, 1).endVertex();
        bb.vertex(m, x + w, y + h, 0).uv(1, 1).endVertex();
        bb.vertex(m, x + w, y, 0).uv(1, 0).endVertex();
        bb.vertex(m, x, y, 0).uv(0, 0).endVertex();
        BufferUploader.drawWithShader(bb.end());
    }

    @Override
    public void tick() {
        if (player.isDone()) finish();
    }

    public void stop() { finish(); }

    private void finish() {
        if (closing) return;
        closing = true;
        minecraft.setScreen(null);
    }

    @Override public void onClose() { }                       // player can't close it
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean keyPressed(int k, int s, int m) { return true; }
    @Override public boolean mouseClicked(double x, double y, int b) { return true; }
    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void removed() {
        player.close();
        if (texLoc != null) minecraft.getTextureManager().release(texLoc);
        if (tex != null) tex.close();
        minecraft.getSoundManager().resume();
        GLFW.glfwSetInputMode(minecraft.getWindow().getWindow(), GLFW.GLFW_CURSOR, GLFW.GLFW_CURSOR_NORMAL);
    }
}
